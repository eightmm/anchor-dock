# AnchorDock

AnchorDock is a single Python package for differentiable molecular pose generation and refinement with three search modes:

- **Reference docking** — anchors a query ligand to a known ligand through single, symmetry-aware multi-position, or multi-fragment MCS mappings.
- **Covalent docking** — detects a warhead, constructs a residue-linked adduct, fixes the protein-side anchor, scans the covalent axis, and optimizes the remaining torsions.
- **Free docking** — performs unanchored multistart SE(3) + torsion gradient search inside a user-defined box.

All modes share the same Torch pose-search engine and pluggable scoring interface. The distribution packages only the `anchor_dock` namespace.

## Installation

```bash
uv sync --group dev
```

or:

```bash
pip install -e .
```

Python 3.12 or newer is required.

## Quick start

### Reference-guided docking

```python
from anchor_dock import dock_reference

result = dock_reference(
    protein_pdb="pocket.pdb",
    reference_ligand="known_pose.sdf",
    query_ligand="CC(C)Cc1ccc(C(C)C(=O)O)cc1",
    mcs_mode="auto",          # auto | single | multi | cross
    scorer="vina",            # vina | vinardo | softdock | custom object
    optimize=True,
)
```

### Covalent docking

```python
from anchor_dock import dock_covalent

result = dock_covalent(
    protein_pdb="protein.pdb",
    query_ligand="C=CC(=O)NCC",
    reactive_residue="CYS145:A",
    scorer="vina",
    optimize=True,
)
```

### Free Torch docking

```python
from anchor_dock import dock_free

result = dock_free(
    protein_pdb="pocket.pdb",
    query_ligand="CCO",
    center=(12.4, -3.1, 8.8),
    box_size=(20.0, 20.0, 20.0),
    num_confs=64,
    num_starts=256,
    scorer="softdock",
)
```

`dock_free` is a randomized multistart local optimizer, not a reimplementation of Vina's Monte Carlo global search. Increase `num_starts`, use multiple conformers, and validate pose recovery for the target system.

## One batch API for every input form

```python
from anchor_dock import dock_batch

results = dock_batch(
    ["CCO", "CCN", "c1ccccc1"],
    mode="free",
    protein_pdb="pocket.pdb",
    scorer="softdock",
    output_dir="screening",
)
```

The same function accepts:

- one SMILES string;
- an RDKit `Chem.Mol`;
- `(ligand, name)` tuples;
- lists, generators, and nested iterables;
- mappings such as `{"smiles": ..., "name": ...}`;
- pandas-like DataFrames;
- open text, binary SDF, and file-like objects;
- SMILES/InChI, SMI, multi-SDF, MOL, MOL2, PDB, CSV, TSV, JSON, JSONL, and NDJSON files;
- gzip, bzip2, or xz-compressed variants of those files;
- directories containing any supported files;
- mixed manifests where each row independently selects `reference`, `covalent`, or `free` mode.

### Generator and RDKit molecules

```python
from rdkit import Chem
from anchor_dock import dock_batch

ligands = (
    item for item in [
        ("CCO", "ethanol"),
        Chem.MolFromSmiles("CCN"),
        {"smiles": "CCC", "name": "propane", "series": "A"},
    ]
)

results = dock_batch(
    ligands,
    mode="free",
    protein_pdb="pocket.pdb",
    scorer="vina",
)
```

### Multi-SDF, SMI, table, or directory

```python
results = dock_batch(
    "libraries/",              # recursively reads supported files
    mode="reference",
    protein_pdb="pocket.pdb",
    reference_ligand="known_pose.sdf",
    num_confs=500,
)
```

### DataFrame

```python
import pandas as pd
from anchor_dock import dock_batch

df = pd.DataFrame({
    "name": ["a", "b"],
    "smiles": ["CCO", "CCN"],
})

results = dock_batch(
    df,
    mode="free",
    protein_pdb="pocket.pdb",
)
```

### Mixed-mode JSONL manifest

```json
{"name":"analog_1","smiles":"CCO","mode":"reference","protein_pdb":"pocket.pdb","reference_ligand":"known.sdf","options":{"mcs_mode":"multi"}}
{"name":"covalent_1","smiles":"C=CC(=O)NCC","mode":"covalent","protein_pdb":"protein.pdb","reactive_residue":"CYS145:A","scorer":"vina"}
{"name":"free_1","smiles":"CCN","mode":"free","protein_pdb":"pocket.pdb","box_size":[18,18,18],"scorer":"softdock"}
```

```python
results = dock_batch("jobs.jsonl", output_dir="mixed_run")
```

Every job receives its own directory and `result.json`; the batch root contains `batch_results.jsonl` and `batch_results.csv`. `resume=True` reuses completed job results.

Runnable templates are under [`examples/batch/`](examples/batch/). See [Batch inputs](docs/BATCH_INPUTS.md) for the full schema.

## Scoring engines

### Vina and Vinardo

The built-in implementation now follows the published and current official functional form:

- official XS radii rather than generic periodic-table van der Waals radii;
- raw interatomic cutoff of 8 Å;
- exact Vina and Vinardo coefficients and piecewise terms;
- full inter- and intramolecular pair terms;
- exclusion of 1–4 and rigid-frame intramolecular pairs;
- separate search energy and reported affinity estimate;
- subtraction of the selected reference pose's intramolecular energy before the rotor correction.

Ordinary SMILES/SDF/PDB inputs do not contain PDBQT XS types, so AnchorDock infers XS-like donor, acceptor, hydrophobic, and polar classes with RDKit and PDB atom metadata. The mathematical form is faithful, while atom typing is an explicit approximation rather than bitwise identity to prepared PDBQT Vina runs.

### SoftDock

`softdock` is a deterministic Torch-native, uncalibrated pair potential composed of smooth steric, contact, hydrophobic, and hydrogen-bond terms. It is useful for pose-search experiments and as a starting point for learned scoring, but its values are arbitrary energy units and must not be interpreted as binding free energies.

See [Scoring](docs/SCORING.md).

## Custom Torch scorer

A custom object only needs `name`, `score_semantics`, `prepare()`, and `score()` methods. It may be an `nn.Module`, use learned embeddings, or call any differentiable model. The shared `DockingEngine` will optimize torsions, translation, and rotation against its `search_energy`.

See [Torch engine](docs/TORCH_ENGINE.md) and the runnable [`examples/custom_scorer.py`](examples/custom_scorer.py).

## CLI

```bash
anchor-dock reference -p pocket.pdb -r known.sdf -q "CCO" --scorer vina
anchor-dock covalent -p protein.pdb -r CYS145:A -q "C=CC(=O)NCC"
anchor-dock free -p pocket.pdb -q "CCO" --box-size 20 --scorer softdock
anchor-dock batch -i jobs.jsonl -o mixed_run
```

## Output semantics

Poses are ranked by `AnchorDock_Search_Energy`, the actual optimization objective. `AnchorDock_Score` is the scorer's reported value:

- Vina/Vinardo: the conformation-independent affinity estimate after intra-reference subtraction and rotor correction;
- SoftDock/custom scorers: the scorer-defined output, normally identical to search energy unless overridden.

Covalent values are conditioned on an already formed adduct and are not reaction energies. SDF records include inter/intra totals and per-term contributions.

## Development

```bash
uv lock
uv sync --frozen --group dev
uv run pytest -q
uv build --wheel
```

## License

MIT
