# Batch input forms

`dock_batch()` accepts homogeneous ligand collections and mixed docking manifests.

## Homogeneous collections

Provide a default mode and shared receptor/anchor arguments:

```python
from anchor_dock import dock_batch

results = dock_batch(
    ["CCO", "CCN"],
    mode="reference",
    protein_pdb="pocket.pdb",
    reference_ligand="known.sdf",
    scorer="vina",
    num_confs=500,
)
```

Accepted ligand objects:

```python
"CCO"                                      # SMILES
Chem.MolFromSmiles("CCO")                  # RDKit Mol
("CCO", "ethanol")                        # source, name
{"smiles": "CCO", "name": "ethanol"}   # mapping
[item1, item2]                              # list or nested iterable
(item for item in collection)               # generator
pandas_dataframe                             # to_dict(orient="records")
open("library.smi")                         # file-like text input
open("library.sdf", "rb")                 # binary multi-SDF stream
```

Accepted paths:

- `.smi`, `.smiles`, `.inchi`, `.txt`
- multi-record `.sdf` / `.sd`
- `.mol`, `.mol2`, `.pdb`, `.ent`
- `.csv`, `.tsv`
- `.json`, `.jsonl`, `.ndjson`
- a directory, recursively scanned for all formats above
- `.gz`, `.bz2`, and `.xz` compressed forms such as `library.sdf.gz` or `jobs.jsonl.xz`

SMI format:

```text
CCO ethanol
CCN ethylamine
c1ccccc1 benzene
```

CSV/TSV format:

```csv
smiles,name,series
CCO,ethanol,A
CCN,ethylamine,A
```

## Mixed-mode manifest

Each row may override the mode, receptor, anchor, scorer, and search settings:

```json
{
  "name": "job_001",
  "smiles": "CCO",
  "mode": "reference",
  "protein_pdb": "pocket.pdb",
  "reference_ligand": "known.sdf",
  "options": {
    "mcs_mode": "multi",
    "num_confs": 1000,
    "scorer": "vina"
  },
  "metadata": {
    "series": "lead_A"
  }
}
```

The following fields are recognized:

| Field | Meaning |
|---|---|
| `ligand`, `query_ligand`, `smiles`, `path`, `mol`, `molecule` | ligand source |
| `name`, `id`, `title` | job name |
| `mode` | `reference`, `covalent`, or `free` |
| `protein_pdb`, `protein` | receptor path |
| `reference_ligand`, `reference`, `ref_ligand` | reference pose |
| `reactive_residue`, `residue` | covalent residue specification |
| `options`, `options_json` | mode-specific option mapping |
| `metadata` | uninterpreted user metadata |

Common option names such as `num_confs`, `scorer`, `opt_steps`, `box_size`, and `rotation_scan_step` can also appear directly as CSV columns. Boolean and numeric strings are coerced automatically. Relative paths in manifest files are resolved relative to the manifest directory.

## Failure and restart behavior

```python
results = dock_batch(
    "jobs.jsonl",
    output_dir="run_001",
    on_error="record",  # record | raise | skip
    resume=True,
)
```

Output layout:

```text
run_001/
├── 00001_job_001/
│   ├── result.json
│   └── ...poses.sdf
├── 00002_job_002/
│   └── result.json
├── batch_results.jsonl
└── batch_results.csv
```

## Runnable files

See `examples/batch/` for SMI, CSV, and mixed JSONL templates.
