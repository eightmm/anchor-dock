# Public API

Only the `anchor_dock` namespace is public.

```python
from anchor_dock import (
    dock_reference,
    dock_covalent,
    dock_free,
    dock_batch,
    dock_reference_batch,
    dock_covalent_batch,
    dock_free_batch,
    LigandRecord,
    DockingJob,
)
```

## `dock_reference`

Required: `protein_pdb`, `reference_ligand`, `query_ligand`.

Important options: `mcs_mode`, `num_confs`, `rmsd_threshold`, `mmff_optimize`, `optimize`, `scorer`, `top_k`.

## `dock_covalent`

Required: `protein_pdb`, `query_ligand`; `reactive_residue` is strongly recommended.

Important options: `pocket_cutoff`, `rotation_scan_step`, `rotation_top_k`, `warhead_index`, `strict_compatibility`, `scorer`, and optimization settings.

## `dock_free`

Required: `protein_pdb`, `query_ligand`.

Important options: `center`, `box_size`, `num_confs`, `num_starts`, `scorer`, and optimization settings.

## `dock_batch`

Accepts all ligand and manifest forms described in `BATCH_INPUTS.md`. The convenience functions set the default mode and delegate to the same `dock_batch()` executor.

## Result dictionary

Every successful mode returns at least:

```python
{
    "mode": "reference" | "covalent" | "free",
    "output_file": "...sdf",
    "num_poses": 20,
    "best_score": -7.1,
    "best_search_energy": -8.3,
    "scorer": "vina",
    "score_semantics": "...",
    "runtime": 1.23,
    "device": "cuda",
}
```
